{

  action = 0;
  
  do {
  
    if ( $1 == ".action" ) {
    
      action++;
      
      if ( action == 1 ) {
        printf("\nset results_red_%d = ( ", action );
      } else {
        printf(")\nset results_red_%d = ( ", action );
      }
           
    }
    
    if ( $1 == ".category" ) {
      printf("%s ", $(NF-4) );
    } 
    
  } while (getline);
  
  printf(")\n");
  
}


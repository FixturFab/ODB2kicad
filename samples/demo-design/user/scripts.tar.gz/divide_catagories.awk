{

  action = 0;
  
  do {
  
    if ( $1 == ".action" ) {
    
      action++;
      
      if ( action == 1 ) {
        printf("\nset action_%d = ( ", action );
      } else {
        printf(")\nset action_%d = ( ", action );
      }
           
    }
    
    if ( $1 == ".category" ) {
      printf("%s ", $2 );
    } 
    
  } while (getline);
  
  printf(")\n");
  
}


{

  action = 0;
  
  do {
  
    if ( $1 == ".action" ) {
    
      action++;
      
      if ( action == 1 ) {
        printf("\nset results_%s_%d = ( ", field, action );
      } else {
        printf(")\nset results_%s_%d = ( ", field, action );
      }
           
    }
    
    if ( field == "s" ) {
      if ( $1 == ".category" ) {
        total = $(NF-4)+$(NF-3)+$(NF-2)+$(NF-1)+$NF;
        printf("%s ", total );
      } 
    } else {
      if ( $1 == ".category" ) {
        printf("%s ", $(NF-5+field) );
      } 
    }
  } while (getline);
  
  printf(")\n");
  
}

